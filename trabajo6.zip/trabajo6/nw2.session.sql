CREATE DATABASE nw2;
USE nw2;

-- Tabla Roles
CREATE TABLE 'roles' (
    'rolescod' varchar (20) NOT NULL,
    `rolesdes` varchar(45) DEFAULT NULL,
  `rolesest` char(4) DEFAULT NULL,
  PRIMARY KEY (`rolescod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Tabla Funciones
CREATE TABLE `funciones` (
  `fncod` varchar(260) NOT NULL,
  `fndes` varchar(260) DEFAULT NULL,
  `fnest` char(4) DEFAULT NULL,
  `fntyp` char(4) DEFAULT NULL,
  PRIMARY KEY (`fncod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Tabla Usuarios
CREATE TABLE `usuario` (
  `usercod` bigint(10) NOT NULL AUTO_INCREMENT,
  `useremail` varchar(80) DEFAULT NULL,
  `username` varchar(80) DEFAULT NULL,
  `userpswd` varchar(128) DEFAULT NULL,
  `userest` char(4) DEFAULT NULL,
  `userrole` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`usercod`),
  CONSTRAINT `user_role_key` FOREIGN KEY (`userrole`) REFERENCES `roles` (`rolescod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `funciones_roles` (
  `rolescod` varchar(20) NOT NULL,
  `fncod` varchar(260) NOT NULL,
  `fnrolest` char(4) DEFAULT NULL,
  `fnexp` datetime DEFAULT NULL,
  PRIMARY KEY (`rolescod`, `fncod`), -- Llave Primaria Compuesta
  KEY `rol_funcion_key_idx` (`fncod`),
  -- Relación con Roles
  CONSTRAINT `funcion_rol_key` FOREIGN KEY (`rolescod`) 
    REFERENCES `roles` (`rolescod`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  -- Relación con Funciones
  CONSTRAINT `rol_funcion_key` FOREIGN KEY (`fncod`) 
    REFERENCES `funciones` (`fncod`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `bitacora` (
  `bitacoracod` int(14) NOT NULL AUTO_INCREMENT,
  `bitacorafch` datetime DEFAULT NULL,
  `bitprograma` varchar(260) DEFAULT NULL,
  `bitdescripcion` varchar(260) DEFAULT NULL,
  `bitobservacion` mediumtext,
  `bitTipo` char(4) DEFAULT NULL,
  `bitusuario` bigint(23) DEFAULT NULL,
  PRIMARY KEY (`bitacoracod`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
<?php

namespace Controllers;

use \Dao\Products\Products as ProductDao;
use \Views\Renderer as Renderer;
use \Utilities\Site as Site;

class HomeController extends PublicController
{
  public function run(): void
  {
    Site::addLink("public/css/products.css");
    $viewData = [];
    $viewData["productOnSale"] = ProductDao::getDailyDeals();
    $viewData["productHighlighted"] = ProductDao::getFeaturedProduct();
    $viewData["productNew"] = ProductDao::getNewProduct();
    Renderer::render("home", $viewData);
  }
}
?>
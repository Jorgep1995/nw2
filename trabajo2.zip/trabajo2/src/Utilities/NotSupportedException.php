<?php
namespace Utilities;
use Exception;

class NotSupportedException extends Exception
{

}

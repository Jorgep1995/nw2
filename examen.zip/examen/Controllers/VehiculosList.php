<?php
namespace Controllers;

class VehiculosList extends \Controllers\PublicController {
    public function run() :void {
        $viewData = array();
        $viewData["vehiculos"] = \Models\Vehiculos::obtenerTodos();
        \Views\Renderer::render("vehiculos_list", $viewData);
    }
}
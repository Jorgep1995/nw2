<?php
namespace Controllers;

use Models\Vehiculos;
use Views\Renderer;

class VehiculoForm extends \Controllers\PublicController {
    private $viewData = [];
    private $mode = "INS"; // Modo por defecto
    private $modeDescriptions = [
        "INS" => "Nuevo Vehículo",
        "UPD" => "Editando %s %s",
        "DEL" => "Eliminando %s %s",
        "DSP" => "Detalle de %s %s"
    ];

    public function run() :void {
        $this->init();
        if ($this->isPostBack()) {
            $this->procesarPost();
        } else {
            $this->prepararVista();
        }
        $this->render();
    }

    private function init() {
        $this->mode = $_GET["mode"] ?? "INS";
        $this->viewData["id_vehiculo"] = $_GET["id"] ?? 0;
        $this->viewData["tokenXSS"] = bin2hex(random_bytes(32)); // Implementación Seguridad XSS
        $_SESSION["tokenXSS"] = $this->viewData["tokenXSS"];
    }

    private function procesarPost() {
        // 1. Validar Token XSS
        if ($_POST["tokenXSS"] !== $_SESSION["tokenXSS"]) {
            die("Error de seguridad: Token Inválido.");
        }

        // 2. Capturar datos y Validar (Punto 6 de la instrucción)
        $this->viewData["marca"] = htmlspecialchars($_POST["marca"]); // Protección XSS
        $this->viewData["modelo"] = htmlspecialchars($_POST["modelo"]);
        $this->viewData["año_fabricacion"] = intval($_POST["año_fabricacion"]);
        $this->viewData["tipo_combustible"] = $_POST["tipo_combustible"];
        $this->viewData["kilometraje"] = intval($_POST["kilometraje"]);

        if (empty($this->viewData["marca"])) {
            $this->viewData["has_errors"] = true;
            $this->viewData["error_marca"] = "La marca es requerida.";
            return;
        }

        // 3. Ejecutar acción según el modo
        switch ($this->mode) {
            case "INS":
                Vehiculos::insertar($this->viewData["marca"], $this->viewData["modelo"], $this->viewData["año_fabricacion"], $this->viewData["tipo_combustible"], $this->viewData["kilometraje"]);
                header("Location: index.php?page=VehiculosList");
                break;
            case "UPD":
                // Aquí llamarías a Vehiculos::actualizar(...)
                break;
            case "DEL":
                // Aquí llamarías a Vehiculos::eliminar(...)
                break;
        }
    }

    private function prepararVista() {
        if ($this->mode !== "INS") {
            $registro = Vehiculos::obtenerPorId($this->viewData["id_vehiculo"]);
            $this->viewData = array_merge($this->viewData, $registro);
        }
        $this->viewData["mode_desc"] = sprintf($this->modeDescriptions[$this->mode], $this->viewData["marca"] ?? '', $this->viewData["modelo"] ?? '');
        $this->viewData["readonly"] = ($this->mode === 'DEL' || $this->mode === 'DSP') ? 'readonly' : '';
        $this->viewData["show_btn"] = ($this->mode !== 'DSP');
    }

    private function render() {
        Renderer::render("vehiculo_form", $this->viewData);
    }
}
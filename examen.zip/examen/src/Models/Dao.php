<?php
namespace Models;

use PDO;
use Exception;

abstract class Dao {
    private static $conn = null;

    // Método para obtener la conexión (Singleton)
    private static function getConn() {
        if (self::$conn == null) {
            // Ajusta estos valores a tu configuración de base de datos
            $host = "127.0.0.1";
            $user = "root"; 
            $pass = ""; 
            $db   = "nombre_de_tu_base_de_datos"; 
            
            try {
                $connStr = "mysql:host=$host;dbname=$db;charset=utf8mb4";
                self::$conn = new PDO($connStr, $user, $pass);
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch (Exception $ex) {
                die("Error al conectar a la base de datos: " . $ex->getMessage());
            }
        }
        return self::$conn;
    }

    // Para SELECT que devuelven muchos registros
    public static function obtenerRegistros($sqlstr, $params = []) {
        $stmt = self::getConn()->prepare($sqlstr);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // Para SELECT que devuelven solo una fila (como buscar por ID)
    public static function obtenerUnRegistro($sqlstr, $params = []) {
        $stmt = self::getConn()->prepare($sqlstr);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    // Para INSERT, UPDATE y DELETE (no devuelven filas, solo filas afectadas)
    public static function executeNonQuery($sqlstr, $params = []) {
        $stmt = self::getConn()->prepare($sqlstr);
        $stmt->execute($params);
        return $stmt->rowCount(); // Devuelve cuántas filas se alteraron
    }
}
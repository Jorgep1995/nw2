<?php
namespace Models;

class Vehiculos extends \Models\Dao {

    public static function obtenerTodos() {
        $sqlstr = "SELECT * FROM DatosVehiculos;";
        return self::obtenerRegistros($sqlstr, []);
    }

    public static function obtenerPorId($id) {
        $sqlstr = "SELECT * FROM DatosVehiculos WHERE id_vehiculo = :id;";
        return self::obtenerUnRegistro($sqlstr, ["id" => $id]);
    }

    public static function insertar($marca, $modelo, $año, $combustible, $km) {
        $sqlstr = "INSERT INTO DatosVehiculos (marca, modelo, año_fabricacion, tipo_combustible, kilometraje) 
                   VALUES (:marca, :modelo, :anio, :combustible, :km);";
        return self::executeNonQuery($sqlstr, [
            "marca" => $marca, 
            "modelo" => $modelo, 
            "año" => $año, 
            "combustible" => $combustible, 
            "km" => $km
        ]);
    }
    public static function actualizar($id, $marca, $modelo, $año, $combustible, $km) {
        $sqlstr = "UPDATE DatosVehiculos SET 
                    marca = :marca, 
                    modelo = :modelo, 
                    año_fabricacion = :año, 
                    tipo_combustible = :combustible, 
                    kilometraje = :km 
                   WHERE id_vehiculo = :id;";
        return self::executeNonQuery($sqlstr, [
            "id" => $id,
            "marca" => $marca,
            "modelo" => $modelo,
            "año" => $año,
            "combustible" => $combustible,
            "km" => $km
        ]);
    }
    public static function eliminar($id) {
        $sqlstr = "DELETE FROM DatosVehiculos WHERE id_vehiculo = :id;";
        return self::executeNonQuery($sqlstr, ["id" => $id]);
    }
}
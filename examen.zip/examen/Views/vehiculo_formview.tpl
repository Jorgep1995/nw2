<section>
    <h2>{{mode_desc}}</h2>
    <form action="index.php?page=VehiculoForm&mode={{mode}}&id={{id_vehiculo}}" method="POST">
        <input type="hidden" name="tokenXSS" value="{{tokenXSS}}" />
        
        <label for="marca">Marca</label>
        <input type="text" name="marca" value="{{marca}}" {{readonly}} required />
        {{if error_marca}}<span class="error">{{error_marca}}</span>{{endif error_marca}}

        <label for="modelo">Modelo</label>
        <input type="text" name="modelo" value="{{modelo}}" {{readonly}} />

        <label for="año_fabricacion">Año</label>
        <input type="number" name="año_fabricacion" value="{{año_fabricacion}}" {{readonly}} />

        <label for="tipo_combustible">Combustible</label>
        <select name="tipo_combustible" {{if readonly}}disabled{{endif readonly}}>
            <option value="Gasolina" {{if combustible_gas}}selected{{endif combustible_gas}}>Gasolina</option>
            <option value="Diesel" {{if combustible_die}}selected{{endif combustible_die}}>Diesel</option>
            <option value="Eléctrico" {{if combustible_ele}}selected{{endif combustible_ele}}>Eléctrico</option>
        </select>

        <label for="kilometraje">Kilometraje</label>
        <input type="number" name="kilometraje" value="{{kilometraje}}" {{readonly}} />

        <div class="actions">
            {{if show_btn}}
                <button type="submit" name="btnGuardar">Confirmar</button>
            {{endif show_btn}}
            <button type="button" onclick="window.location.href='index.php?page=VehiculosList'">Cancelar</button>
        </div>
    </form>
</section>
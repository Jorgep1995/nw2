<h2>Listado de Vehículos</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        {{foreach vehiculos}}
        <tr>
            <td>{{id_vehiculo}}</td>
            <td>{{marca}}</td>
            <td>{{modelo}}</td>
            <td>
                <a href="index.php?page=VehiculoForm&mode=UPD&id={{id_vehiculo}}">Editar</a>
                <a href="index.php?page=VehiculoForm&mode=DEL&id={{id_vehiculo}}">Eliminar</a>
            </td>
        </tr>
        {{endfor vehiculos}}
    </tbody>
</table>
<a href="index.php?page=VehiculoForm&mode=INS">Agregar Nuevo</a>
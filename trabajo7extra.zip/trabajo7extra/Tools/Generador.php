<?php
// Configuración de la base de datos
$host = 'localhost';
$db   = 'tu_base_de_datos';
$user = 'root';
$pass = '';
$tabla = 'usuarios'; // Cambia esto por la tabla que desees procesar

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// 1. Extraer campos de la tabla (Tip: desc table_name)
$resultado = $conn->query("DESC $tabla");
$campos = [];
while ($fila = $resultado->fetch_assoc()) {
    $campos[] = $fila;
}

// Crear carpeta para los archivos generados
$dir = "generado_" . $tabla;
if (!is_dir($dir)) mkdir($dir);

// --- FUNCIONES DE GENERACIÓN ---

// 5. Generar Modelo de Datos
$modeloContent = "<?php\nclass " . ucfirst($tabla) . "Model {\n";
foreach ($campos as $c) { $modeloContent .= "    public $" . $c['Field'] . ";\n"; }
$modeloContent .= "}\n?>";
file_put_contents("$dir/modelo_datos.php", $modeloContent);

// 1. Generar Controlador de Lista
$ctrlLista = "<?php\n// Controlador de Lista para $tabla\n";
$ctrlLista .= "include 'modelo_datos.php';\n";
$ctrlLista .= "\$datos = \$db->query('SELECT * FROM $tabla')->fetchAll();\n";
$ctrlLista .= "include 'plantilla_lista.php';\n?>";
file_put_contents("$dir/controlador_lista.php", $ctrlLista);

// 2. Generar Controlador de Formulario
$ctrlForm = "<?php\n// Controlador de Formulario para $tabla\n";
$ctrlForm .= "if(\$_POST) {\n    // Lógica para INSERT o UPDATE\n    echo 'Datos guardados';\n}\n";
$ctrlForm .= "include 'plantilla_formulario.php';\n?>";
file_put_contents("$dir/controlador_formulario.php", $ctrlForm);

// 3. Generar Plantilla de Lista (HTML)
$plantillaLista = "<table>\n    <thead>\n        <tr>\n";
foreach ($campos as $c) { $plantillaLista .= "            <th>" . ucfirst($c['Field']) . "</th>\n"; }
$plantillaLista .= "        </tr>\n    </thead>\n    <tbody>\n";
$plantillaLista .= "        <?php foreach(\$datos as \$reg): ?>\n        <tr>\n";
foreach ($campos as $c) { $plantillaLista .= "            <td><?php echo \$reg['" . $c['Field'] . "']; ?></td>\n"; }
$plantillaLista .= "        </tr>\n        <?php endforeach; ?>\n    </tbody>\n</table>";
file_put_contents("$dir/plantilla_lista.php", $plantillaLista);

// 4. Generar Plantilla de Formulario
$plantillaForm = "<form method='POST'>\n";
foreach ($campos as $c) {
    $label = ucfirst($c['Field']);
    $plantillaForm .= "    <label>$label</label>\n";
    $plantillaForm .= "    <input type='text' name='" . $c['Field'] . "' placeholder='$label'><br>\n";
}
$plantillaForm .= "    <button type='submit'>Guardar</button>\n</form>";
file_put_contents("$dir/plantilla_formulario.php", $plantillaForm);

echo "¡Archivos generados con éxito en la carpeta: $dir!";
?>